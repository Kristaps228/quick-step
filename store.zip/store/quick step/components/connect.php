<?php

$db_name = 'mysql:host=localhost;dbname=shop_db';
$user_name = 'root';
$user_password = '';

try {
    $conn = new PDO($db_name, $user_name, $user_password);
    // Установим режим ошибок PDO на исключение
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Установим режим выборки PDO на ассоциативный массив
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Если произошла ошибка подключения, выведем сообщение об ошибке
    echo 'Connection failed: ' . $e->getMessage();
    // Остановим выполнение скрипта
    exit();
}

?>
